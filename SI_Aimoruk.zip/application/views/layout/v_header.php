<body>

<div class="super_container">

	<!-- Header -->

	<header class="header">
			
		<!-- Top Bar -->
		<div class="top_bar">
			<div class="top_bar_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="top_bar_content d-flex flex-row align-items-center justify-content-start">
								<h4>SISTEMA INFORMASAUN APOTEK OSAN MEAN</h4>
								<div class="top_bar_login ml-auto">
									<div class="login_button" style="background-color:lightblue"><a href="<?= base_url('login')?>">Login</a></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>				
		</div>

		