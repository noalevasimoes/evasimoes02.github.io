<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontaktu</title>
</head>
<body style="background-image:url(<?= base_url() ?>template/front-end/images/kj.jpg)">
<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<h1 class="section_title" style="text-align: center;">Kontaktu ho Ami!</h1><br>
						<div class="section_subtitle">
							<p style="font-family: Georgia, 'Times New Roman', Times, serif; font-size: 2rem; text-align:justify;">Karik ita boot 
                            sira sei duvida ho ami nia lokalizsaun Apotek Osan Mean bele kontaktu ami Direitamente Liu husi :
						</p><br>
                        <p>No Telefone  : +670 74323324</p><br>
                        <p>No.WA        : 74323324</p><br>
                        <p>Email        : noalevasimoes02@gmail.com</p><br></div>
					</div>
				</div>
			</div>
</body>
</html>
