<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apotek</title>
</head>
<body style="background-image:url(<?= base_url() ?>template/front-end/images/kj.jpg)">
<div class="row">
				<div class="col">
					<div class="section_title_container text-center">
						<h1 class="section_title" style="text-align: center;">Saida mak APotek?</h1><br>
						<div class="section_subtitle">
							<p style="font-family: Georgia, 'Times New Roman', Times, serif; font-size: 2rem; text-align:justify;">Apotek hanesan fasilidade saude nian ida nebe mak nia funsaun nebe importante hodi oferese aimoruk ba pasiente 
                                
                            sira. Iha prosesu negosiu, apotek presiza iha manejamentu diak hanesan : halo manejamentu ba dados aimoruk, dados
                            
                            tranzaksaun, stok aimoruk ho maneira nebe efektivu no efisiensia. Sistema informasaun manejamentu (SIM) sai hanesan 
                            
                            solusaun id aba problema manejamentu aimoruk iha apotek ida.
						</p></div>
					</div>
				</div>
			</div>
</body>
</html>
