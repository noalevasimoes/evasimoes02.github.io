 <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar" role="navigation" style="background-color: #f8f9fa;">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu" style="background-color: #f8f9fa;">
                            <h3 style="color: #007bff;">Noaleva Faria Simoes</h3>
                            <li>
                                <a href="<?= base_url('admin')?>" style="color: #007bff;"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                            </li>
                            <li>
                                <a href="<?= base_url('aimoruk')?>" style="color: #007bff;"><i class="fa fa-table fa-fw"></i> Aimoruk</a>
                            </li>
                            <li>
                                <a href="<?= base_url('supplier')?>" style="color: #007bff;"><i class="fa fa-table fa-fw"></i> Supplier</a>
                            </li>
                            <li>
                                <a href="<?= base_url('kategoria')?>" style="color: #007bff;"><i class="fa fa-table fa-fw"></i> Kategoria</a>
                            </li>
                            <li>
                                <a href="<?= base_url('kliente')?>" style="color: #007bff;"><i class="fa fa-table fa-fw"></i> Kliente</a>
                            </li>
                            <li>
                                <a href="forms.html" style="color: #007bff;"><i class="fa fa-edit fa-fw"></i> Forms</a>
                            </li>
                            <li class="active">
                                <a href="<?=base_url('login/logout')?>" style="color: #007bff;"><i class="fa fa-sign-out"></i>Logout</a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>

            <!-- Konten Halaman -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header"><?= $title2?></h1>
                        