<!-- Home -->

	<div class="home">
		<div class="home_slider_container">
			
			<!-- Home Slider -->
			<div class="owl-carousel owl-theme home_slider">
				
				<!-- Home Slider Item -->
				<div class="owl-item">
					<div class="home_slider_background" style="background-image:url(<?= base_url() ?>template/front-end/images/j.jpg)"></div>
					
				</div>

			</div>
		</div>
	</div>
	<!-- Popular Courses -->

	
